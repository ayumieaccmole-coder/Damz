module.exports = {
  TOKEN_BOT_XYAALZ: "8438508034:AAEIiiTllAL8ToGgihNenEcnjt9EDC1XNko",
  OWNER_ID: "7870295166",
};

/*
  Creator : DamzOfficial
  Telegram : t.me/DamzOfficiall
*/